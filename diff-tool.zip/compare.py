import json
import requests
import base64
from datetime import datetime
from deepdiff import DeepDiff

def fetch_json(url, username=None, password=None):
    headers = {}
    if username and password:
        credentials = "{}:{}".format(username, password)
        credentials_encoded = base64.b64encode(credentials.encode()).decode('utf-8')
        headers['Authorization'] = 'Basic {}'.format(credentials_encoded)

    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception("Failed to fetch JSON from {}. Status code: {}".format(url, response.status_code))

def compare_json(json1, json2):
    ddiff = DeepDiff(json1, json2)
    return ddiff

def generate_html_report(json1_url, json2_url, ddiff, output_file="report.html"):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(output_file, "w") as f:
        f.write("<html>\n<head>\n<title>JSON Structural Diff Report</title>")
        f.write("<style>\n")
        f.write("body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 20px; }\n")
        f.write(".header { font-size: 24px; margin-bottom: 10px; }\n")
        f.write(".file { font-size: 18px; font-weight: bold; margin-bottom: 10px; }\n")
        f.write(".diff { font-family: 'Courier New', Courier, monospace; }\n")
        f.write(".added { color: #008000; }\n")
        f.write(".removed { color: #ff0000; }\n")
        f.write("</style>\n")
        f.write("</head>\n<body>\n")
        f.write("<div class='header'>JSON Structural Diff Report ({})</div>\n".format(timestamp))

        if not ddiff:
            f.write("<p>No structural differences found.</p>\n")
        else:
            f.write("<div class='file'>")
            f.write("Comparison between <span class='added'>{}</span> and <span class='removed'>{}</span>:</div>\n".format(json1_url, json2_url))
            f.write("<div class='diff'>\n")

            for change_type, changes in ddiff.items():
                if isinstance(changes, dict):
                    for change, details in changes.items():
                        path = change
                        old_value = details.get('old_value', '')
                        new_value = details.get('new_value', '')

                        f.write("<div>{}</div>\n".format(path))
                        f.write("<div class='added'>")
                        f.write("  {}<br>".format(json.dumps(old_value, indent=2).replace('\n', '<br>')))
                        f.write("</div>\n")
                        f.write("<div class='removed'>")
                        f.write("  {}<br>".format(json.dumps(new_value, indent=2).replace('\n', '<br>')))
                        f.write("</div>\n")
                else:
                    f.write("<p>{}</p>\n".format(changes))

            f.write("</div>\n")

        f.write("</body>\n</html>")

if __name__ == "__main__":
    url1 = "https://www.firstdirect.com/content/fsdt/en_gb/mobile-app/status.json"
    url2 = "https://fsdt.dxp1.preprod.eu.dynp.cloud1.vv1865.com/content/fsdt/en_gb/mobile-app/status.json"
    username = "amsuser"  # Replace with your username (optional)
    password = "Pr0tectamsuser"  # Replace with your password (optional)

    try:
        json1 = fetch_json(url1, username, password)
        json2 = fetch_json(url2, username, password)

        ddiff = compare_json(json1, json2)

        generate_html_report(url1, url2, ddiff)

        print("Structural Diff report generated successfully. Check 'report.html' for details.")

    except Exception as e:
        print("Error: {}".format(e))
