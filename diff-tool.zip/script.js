import axios from "axios";
import * as jsondiffpatch from "jsondiffpatch";
import fs from "fs/promises";
import path from "path";
import * as htmlFormatter from "jsondiffpatch/formatters/html";

let styles;

// Function to fetch JSON data from a URL
async function fetchJson(url) {
  try {
    const response = await axios.get(url, {
      headers: { "Content-Type": "application/json" },
      auth: {
        username: process.env.npm_config_dxp_user,
        password: process.env.npm_config_dxp_pass,
      },
    });
    return response.data;
  } catch (error) {
    throw new Error(`Error fetching JSON from ${url}: ${error.message}`);
  }
}

// Function to compare two JSON objects and generate a diff
async function generateDiff({ json1, json2, url1, url2 }) {
  const delta = jsondiffpatch.diff(json1, json2);
  styles = styles || (await fs.readFile("styles.css", "utf8"));
  return `
    <!doctype html>
    <html dir="ltr">
      <head>
        <meta charset="utf-8">
        <style>${styles}</style>
      </head>
      <body>
        <h1>JSON diff created :${new Date().toGMTString()}</h1>
        <ul class="urls">
          <li>${url1}</li>
          <li>${url2}</li>
        </ul>
        ${
          delta
            ? htmlFormatter.format(delta, json2)
            : '<p class="error">No differences found.</p>'
        }
      </body>
    </html>
  `;
}

// Function to save HTML report to a file
async function saveHtmlReport(html, output) {
  try {
    await fs.writeFile(output, html);
    console.log(`HTML report saved to ${output}`);
  } catch (error) {
    throw new Error(`Error saving HTML report: ${error.message}`);
  }
}

// Main function
async function compareAndGenerateReport({ url1, url2, output }) {
  try {
    // Fetch JSON data from URLs
    const json1 = await fetchJson(url1);
    const json2 = await fetchJson(url2);

    // Generate HTML diff report
    const htmlDiff = await generateDiff({ json1, json2, url1, url2 });

    // Save HTML report to a file
    await saveHtmlReport(htmlDiff, output);
  } catch (error) {
    console.error(error.message);
  }
}

// Array of items to report on
[
  // {
  //   url1: "https://fsdt.prod-proving.prod.eu.dynp.cloud1.vv1865.com/content/fsdt/en_gb/mobile-app/status.json",
  //   url2: "https://www.firstdirect.com/content/fsdt/en_gb/mobile-app/status.json",
  //   output: "status_json.html",
  // },
  {
    url1: "https://www.firstdirect.com/content/wpb/fsdt/utilities/master-with-interstitial.fsdt.json",
    url2: "https://fsdt.prod-proving.prod.eu.dynp.cloud1.vv1865.com/content/wpb/fsdt/utilities/master-with-interstitial.fsdt.json",
    output: "master_json.html",
  },
  // {
  //   url1: "https://fsdt.prod-proving.prod.eu.dynp.cloud1.vv1865.com/content/wpb/fsdt/en_gb/common/feature-configuration.fsdt.json",
  //   url2: "https://www.firstdirect.com/content/wpb/fsdt/en_gb/common/feature-configuration.fsdt.json",
  //   output: "features_json.html",
  // },
].forEach((item) => compareAndGenerateReport(item));
